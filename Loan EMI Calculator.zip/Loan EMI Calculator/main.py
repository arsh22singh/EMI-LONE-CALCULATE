# Loan EMI Calculator using Flask

from flask import Flask, render_template, request
# Initialize the Flask application
app = Flask(__name__)
# Function to calculate EMI
def calculate_emi(principal, rate, tenure): 
    monthly_rate = rate / 12 / 100
    months = tenure * 12
    # EMI formula
    if monthly_rate == 0:
        emi = principal / months
    else:
        emi = principal * monthly_rate * (1 + monthly_rate)**months / ((1 + monthly_rate)**months - 1)
    return round(emi, 2) # Rounded to 2 decimal places
# Route for the home page
@app.route('/', methods=['GET', 'POST'])
def index(): # Handle form submission
    emi = None
    if request.method == 'POST': # Get form data
        principal = float(request.form['principal']) # Loan amount
        rate = float(request.form['rate']) # Annual interest rate
        tenure = float(request.form['tenure']) # Loan tenure in years
        emi = calculate_emi(principal, rate, tenure) # Calculate EMI
    return render_template('index.html', emi=emi) # Render the template with EMI value
# Run the application
if __name__ == '__main__':
    app.run(debug=True)


